document.querySelector('.modal-close').addEventListener('click', (e) => {
    e.preventDefault()
    document.querySelector('.modal').classList.remove("is-active")
})