<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

header('Access-Control-Allow-Methods: GET,PUT,POST,DELETE,OPTIONS');
header('Access-Control-Allow-Headers: Content-type,Accept,X-Access-Token,X-Key,Authorization');

$url = "https://killer-cepegra.xyz/api/";

if($_SERVER['REQUEST_METHOD'] == "GET") :
$visits = array(
	array(
		"title" 	=> "Kremlin",
		"title2"	=> " de Kazan",
		"img"		=> $url."images/Kazan_Kremlin.jpg",
		"text_img"	=> "Kremlin de Kazan",
		"situation"	=> "Center of the city",
		"ss_titre"	=> "Kremlin historique du Tatarstan",
		"texte"		=> "Construit sous les ordres d'Ivan IV, sur les ruines de l'ancien château des khans de Kazan. Il est inscrit sur la liste du patrimoine mondial de l'UNESCO.",
		"prix"		=> "250",
		"complement"=> "Le kremlin de Kazan abrite plusieurs vieux édifices, le plus ancien étant la cathédrale de l'Annonciation (1554-1562), la seule église russe du xvie siècle ayant six trumeaux et cinq absides. Comme beaucoup d'autres édifices à Kazan de cette période, elle a été construite à partir du grès pâle de la région et non de briques. Elle serait l'œuvre de l'architecte semi-légendaire Postnik Yakovlev, mais c'est purement spéculatif. Le beffroi de la cathédrale fut érigé en cinq étapes selon les ordres du tsar Ivan IV ; il imite le clocher d'Ivan le Grand du kremlin de Moscou et fut détruit par les Soviétiques en 1930."
	),
	array(
		"title" 	=> "Mosquée",
		"title2"	=> "Qolsharif",
		"img"		=> $url."images/d0bad183d0bb_d188d0b0d180d0b8d184_4-tataristan-moque-qulsharif.jpg",
		"text_img"	=> "Mosquée Qolsharif",
		"situation"	=> "Center of the city",
		"ss_titre"	=> "La Renaissance ottomane",
		"texte"		=> "La mosquée Qolşärif est un édifice religieux du kremlin de la ville de Kazan en Russie. Elle était la plus grande mosquée d'Europe après celle d'Istanbul.",
		"prix"		=> "200",
		"complement"=> "Récemment reconstruite, et la résidence du gouverneur (1843-1853), œuvre de Constantin Thon, aujourd'hui le palais du président du Tatarstan. Le palais est supposé être construit sur le site du palais des khans."
	),
	array(
		"title" 	=> "Temple",
		"title2"	=> "of All Religions",
		"img"		=> $url."images/temple_multiple.jpg",
		"text_img"	=> "Le temple de toutes les religions",
		"situation"	=> "West of the city",
		"ss_titre"	=> "Temple, mosquée, synagogue,...",
		"texte"		=> "Le temple de toutes les religions est un complexe unique comprenant plusieurs types d'architecture religieuse.",
		"prix"		=> "300",
		"complement"=> "Le temple de toutes les religions (ou temple universel des religions) est un complexe architectural situé dans le « microdistrict » de Staroye Arakchino, à l’intérieur de la municipalité de Kazan en Russie. Étroitement regroupé sur une petite parcelle de terrain, le complexe se compose de plusieurs coupoles, minarets et clochers représentant l’architecture religieuse de 12 grandes religions du monde. On y trouve la croix chrétienne, le croissant musulman, l’étoile de David et le dôme chinois; cependant, aucune cérémonie ne s’y déroule à l’intérieur et on n’entend aucun son de prière, car ce n’est pas un temple comme un autre. Le bâtiment est tout simplement un centre culturel, et non de culte, qui sert aussi de résidence à son propriétaire, l’artiste et philanthrope local Ildar Khanov, et à ses assistants qui pratiquent la guérison spirituelle à leurs patients consentants."
	),
	array(
		"title" 	=> "Bauman",
		"title2"	=> "Street",
		"img"		=> $url."images/Baumana_Street_Kazan_Russia_2009_sept_06.jpg",
		"text_img"	=> "Bauman Street, rue commerçante",
		"situation"	=> "Center of the city",
		"ss_titre"	=> "Nikolay Bauman, révolutionnaire",
		"texte"		=> "La Rue Baumana est une rue piétonne située au cœur de Kazan. La rue commence au pied du Kremlin et atteint la place Tukay, la place centrale de la ville.",
		"prix"		=> "Gratuit",
		"complement"=> "La rue Baumana est une rue piétonne située au cœur de Kazan, capitale du Tatarstan, en Russie. Il porte le nom de Nikolay Bauman, un révolutionnaire russe, et est situé dans le centre de la ville. La rue commence au pied du Kremlin et atteint la place Tukay, la place centrale de la ville."
	),
	array(
		"title" 	=> "Riviera",
		"title2"	=> "Aquapark",
		"img"		=> $url."images/aqua-photo00.jpg",
		"text_img"	=> "Aqua Park",
		"situation"	=> "Center of the city",
		"ss_titre"	=> "Le pouvoir magique et curatif de l'eau",
		"texte"		=> "L'un des plus grands au monde&nbsp;! Plus de 50 attractions différentes pour que chacun puisse trouver sa véritable vague d'émotions !",
		"prix"		=> "500",
		"complement"=> "Les amateurs de divertissement extrême sur la dignité apprécient les collines de virages serrés , où le temps et encore , il serait souhaitable de faire un vol étourdi, avec des jets d'eau.
C'est ici que les plus courageux et les plus désespérés ont battu des records en s'essayant à la descente.
Avec toute la famille ou une compagnie amicale et joyeuse, vous pouvez monter dans le bateau rond et voler dans le tuyau de la glissière jaune «Niagara» ou bien, avec votre petite amie, faire une incroyable descente avec des virages inattendus de la glissière «Anaconda».
Pour sentir le souffle de la mer, il n'est pas du tout nécessaire de franchir des distances de milliers de kilomètres: vous pouvez vous balancer sur les vagues ici, au parc aquatique Riviera de Kazan, dans sa piscine à vagues!"
	),
	array(
		"title" 	=> "Cathédrale",
		"title2"	=> "de l'Annonciation",
		"img"		=> $url."images/cat.jpg",
		"text_img"	=> "Cathédrale orthodoxe de l'Annonciation",
		"situation"	=> "South of the city",
		"ss_titre"	=> "Architecture orthodoxe russe",
		"texte"		=> "Annexée au kremlin, c'est une église orthodoxe d'architecture  russe datant du XIVᵉ siècle et modifiée jusqu'au XIXᵉ siècle.",
		"prix"		=> "Gratuit",
		"complement"=> "L'icône de Notre-Dame de Kazan (en russe : Казанская Богоматерь) est une icône ... Elle a été offerte par Jean-Paul II au patriarcat de Moscou en 2004. Elle se trouve aujourd'hui dans la cathédrale de l'Annonciation du kremlin de Kazan."
	),
	array(
		"title" 	=> "Ozero",
		"title2"	=> "Goluboye",
		"img"		=> $url."images/goluboe_ozero.jpg",
		"text_img"	=> "Le lac Ozero Goluboye",
		"situation"	=> "North of the city",
		"ss_titre"	=> "Lac kartique de Kazan",
		"texte"		=> "Textuellement \"Lac Bleu\", sa profondeur maximale est de 18&nbsp;m. L'eau a rempli une caverne creusée dans du sédiment glaciaire qui s'est effondrée.",
		"prix"		=> "Gratuit",
		"complement"=> "L’eau du lac doit sa couleur bleue à la présence d’une boue de sel. C’est pourquoi nombreuses sont des personnes souffrant de maladies de peau qui viennent ici pour suivre un traitement."
	),
	array(
		"title" 	=> "Museum",
		"title2"	=> "Republic Tatarstan",
		"img"		=> $url."images/musee.jpg",
		"text_img"	=> "Musée du Tatarstan",
		"situation"	=> "Center of the city",
		"ss_titre"	=> "L'histoire du Tatarstan",
		"texte"		=> "Le musée principal occupe le bâtiment de l'ancien Gostiny Dvor, qui est un monument historique et culturel d'importance fédérale.",
		"prix"		=> "120",
		"complement"=> "Superbe musée qui nous plonge dans le passé soviétique. On y trouve de nombreux objets du quotidien de l'époque, de belles images mais aussi des costumes militaires que l'on peut porter le temps d'une photo."
	),
	array(
		"title" 	=> "Kaban",
		"title2"	=> "Lakes",
		"img"		=> $url."images/lake.jpg",
		"text_img"	=> "Les lacs de Kaban",
		"situation"	=> "East of the city",
		"ss_titre"	=> "De l'eau en pleine ville",
		"texte"		=> "Les lacs de Kaban sont des lacs qui combiné avec d'autres (Nizhny Kaban, Verkhny Kaban et Sredny Kaban) font 1,86 kilomètres carrés, le plus grand lac du Tatarstan.",
		"prix"		=> "120",
		"complement"=> ""
	),
	array(
		"title" 	=> "Millennium",
		"title2"	=> "Bridge",
		"img"		=> $url."images/Kazan_Millennium_Bridge_08-2016.jpg",
		"text_img"	=> "Pont du Millennium de Kazan",
		"situation"	=> "North of the city",
		"ss_titre"	=> "Pont à haubans",
		"texte"		=> "Le pont Millennium enjambe la rivière Kazanka. Construit pour le millième anniversaire de Kazan, célébré en 2005, la forme de son pylône est un M.",
		"prix"		=> "Gratuit",
		"complement"=> "Le Millennium Bridge est un pont à haubans qui enjambe la rivière Kazanka, à Kazan, au Tatarstan, en Russie. Son nom tire son origine du millième anniversaire de Kazan, largement célébré en 2005, et de la forme de son pylône en forme de M."
	),
	array(
		"title" 	=> "Kazan",
		"title2"	=> "Hermitage",
		"img"		=> $url."images/hermitage.jpg",
		"text_img"	=> "Hermitage de Kazan",
		"situation"	=> "Center of the city",
		"ss_titre"	=> "Palais des congrès et centre d'expositions",
		"texte"		=> "Musée avec diverses expositions et centre de congrès internationnaux, l'Hermitage est un pôle culturel imposrtant du centre ville.",
		"prix"		=> "180",
		"complement"=> "Une exposition intéressante de divers portraits. Le seul inconvénient était le manque de signalisation en anglais.

Le musée se trouve dans le centre de Kazan, à côté du musée des beaux-arts du Tatarstan (qui vaut également la peine). Le centre de Kazan abrite également le musée de la Seconde Guerre mondiale et le musée d'histoire naturelle, dont les droits d'entrée sont séparés."
	),
	array(
		"title" 	=> "Eglise",
		"title2"	=> "St Pierre et Paul",
		"img"		=> $url."images/pierre-paul.jpg",
		"text_img"	=> "Eglise Saint-Pierre-et-Saint-Paul",
		"situation"	=> "Center of the city",
		"ss_titre"	=> "Architecture baroque",
		"texte"		=> "L’église Saint-Pierre-et-Paul est une église orthodoxe baroque située dans la vieille ville. Elle est associée à Pierre Le Grand arrivé à Kazan avant sa campagne persienne.",
		"prix"		=> "Gratuit",
		"complement"=> "La Cathédrale Saint-Pierre-et-Saint-Paul est une cathédrale qui a été construit de 1723 à 1726. "
	)
);
$nb_insert = count($visits);

$visits['number'] = $nb_insert;

$visits['title'] = "Kazan";

$visits['baseline'] = "Smart City";

else :
	$visits = "Pas de retour";
endif;


/*echo "<pre>";
print_r($visits);
*/
echo json_encode($visits);
 ?>
